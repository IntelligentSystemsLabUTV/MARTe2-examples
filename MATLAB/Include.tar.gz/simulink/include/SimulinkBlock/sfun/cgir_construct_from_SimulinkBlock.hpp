// Copyright 2009-2011 The MathWorks, Inc.

#pragma once

#include "../sl_core_block_spec.hpp"
#include "sfun_rtwcg.hpp"
